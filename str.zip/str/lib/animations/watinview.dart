import 'package:flutter/material.dart';

class WatingView extends StatefulWidget {
  @override
  _WatinAppState createState() => _WatinAppState();
}

class _WatinAppState extends State<WatingView> with TickerProviderStateMixin {
  AnimationController animationController1,
      animationController2,
      animationController3,
      animationController4;

  Animation<double> animation1, animation2, animation3, animation4;

  @override
  void dispose() {
    animationController1.dispose();
    animationController2.dispose();
    animationController3.dispose();
    animationController4.dispose();
    super.dispose();
  }

  @override
  void initState() {
    animationController1 = AnimationController(
      duration: Duration(milliseconds: 600),
      vsync: this,
    );
    animationController2 = AnimationController(
      duration: Duration(milliseconds: 600),
      vsync: this,
    );
    animationController3 = AnimationController(
      duration: Duration(milliseconds: 600),
      vsync: this,
    );
    animationController4 = AnimationController(
      duration: Duration(milliseconds: 600),
      vsync: this,
    );

    animation1 = Tween(
      begin: 0.0,
      end: 0.1,
    ).animate(
      CurvedAnimation(parent: animationController1, curve: Interval(0.0, 0.1)),
    );

    animation2 = Tween(
      begin: 0.0,
      end: 0.1,
    ).animate(
      CurvedAnimation(parent: animationController2, curve: Interval(0.0, 0.1)),
    );

    animation3 = Tween(
      begin: 0.0,
      end: 0.1,
    ).animate(
      CurvedAnimation(parent: animationController3, curve: Interval(0.0, 0.1)),
    );
    animation4 = Tween(
      begin: 0.0,
      end: 0.1,
    ).animate(
      CurvedAnimation(parent: animationController4, curve: Interval(0.0, 0.1)),
    );

    animationController1.addListener(() {
      setState(() {});
    });
    animationController2.addListener(() {
      setState(() {});
    });
    animationController3.addListener(() {
      setState(() {});
    });
    animationController4.addListener(() {
      setState(() {});
    });

    animationController1.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        animationController1.reverse();
      } else if (status == AnimationStatus.dismissed) {
        animationController1.forward();
      }
    });
    animationController2.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        animationController2.reverse();
      } else if (status == AnimationStatus.dismissed) {
        animationController2.forward();
      }
    });
    animationController3.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        animationController3.reverse();
      } else if (status == AnimationStatus.dismissed) {
        animationController3.forward();
      }
    });
    animationController4.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        animationController4.reverse();
      } else if (status == AnimationStatus.dismissed) {
        animationController4.forward();
      }
    });

    Future.delayed(
      Duration(milliseconds: 1200),
      () => animationController1.forward(),
    );

    Future.delayed(
      Duration(milliseconds: 1400),
      () => animationController2.forward(),
    );
    Future.delayed(
      Duration(milliseconds: 1600),
      () => animationController3.forward(),
    );
    Future.delayed(
      Duration(milliseconds: 1800),
      () => animationController4.forward(),
    );

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              buildBallOne(),
              SizedBox(
                width: 6.0,
              ),
              buildBallTwo(),
              SizedBox(
                width: 6.0,
              ),
              buildBallThree(),
              SizedBox(
                width: 6.0,
              ),
              buildBallFor()
            ],
          ),
        ),
      ),
    );
  }

  Widget buildBallOne() {
    return Container(
      margin: EdgeInsets.only(top: 100 - (animationController1.value * 50)),
      width: 10,
      height: 10,
      decoration: ShapeDecoration(
        shape: CircleBorder(),
        color: Colors.blueAccent[700],
      ),
    );
  }

  Widget buildBallTwo() {
    return Container(
      margin: EdgeInsets.only(top: 100 - (animationController2.value * 50)),
      width: 10,
      height: 10,
      decoration: ShapeDecoration(
        shape: CircleBorder(),
        color: Colors.redAccent[400],
      ),
    );
  }

  Widget buildBallThree() {
    return Container(
      margin: EdgeInsets.only(top: 100 - (animationController3.value * 50)),
      width: 10,
      height: 10,
      decoration: ShapeDecoration(
        shape: CircleBorder(),
        color: Colors.amber[400],
      ),
    );
  }

  Widget buildBallFor() {
    return Container(
      margin: EdgeInsets.only(top: 100 - (animationController4.value * 50)),
      width: 10,
      height: 10,
      decoration: ShapeDecoration(
        shape: CircleBorder(),
        color: Colors.greenAccent[700],
      ),
    );
  }
}
