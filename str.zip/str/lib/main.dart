import 'dart:async';

import 'package:bottom_navy_bar/bottom_navy_bar.dart';
import 'package:flutter/gestures.dart';

import 'package:flutter/material.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:store2/pages/bigdeatial.dart';
import 'package:store2/pages/groups.dart';
import 'package:store2/pages/home.dart';

import 'package:flutter/services.dart';

import 'package:store2/pages/signup.dart';

import 'pages/basket.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
    return MaterialApp(
      home: AppState(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class AppState extends StatefulWidget {
  AppState({Key key}) : super(key: key);

  @override
  _AppStateState createState() => _AppStateState();
}

class _AppStateState extends State<AppState> {
  var pages = [HomeApp(), GroupsApp(), BasketApp(), SignupApp()];
  bool shopcartcount;
  int counter = 0;

  @override
  void initState() {
    shopcartcount = false;
    super.initState();
  }

  txt(v) {
    return Text(
      v,
      style: TextStyle(fontFamily: 'Vazir'),
    );
  }

  var currentindex = 0;
  var currentpage = 0;

  _changeItem(int bottomnavigationindex) {
    setState(() {
      currentindex = bottomnavigationindex;
      currentpage = bottomnavigationindex;
      shopcartcount = true;
      counter += 1;
    });
  }

  actionbutton() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(4),
      child: AnimatedContainer(
        color: currentpage == 2 ? Colors.white : Colors.transparent,
        duration: Duration(milliseconds: 1300),
        width: currentpage == 2 ? MediaQuery.of(context).size.width : 55,
        height: counter > 0 ? 68 : 0,
        child: Stack(
          children: <Widget>[
            Positioned(
              top: 24,
              right: 10,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(5),
                child: Container(
                  color: currentpage == 2
                      ? Colors.transparent
                      : Colors.redAccent[700],
                  width: 23,
                  height: 22,
                  child: Center(
                    child: Text(
                      "$counter",
                      overflow: TextOverflow.fade,
                      style: TextStyle(
                          color: currentpage == 2
                              ? Colors.transparent
                              : Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Vazir'),
                    ),
                  ),
                ),
              ),
            ),
            Align(
                alignment: Alignment.bottomLeft,
                child: Icon(
                  Icons.add_shopping_cart,
                  color: currentpage == 2
                      ? Colors.transparent
                      : Colors.redAccent[400],
                  size: 27,
                )),
            Positioned(
                top: 9,
                right: 5,
                child: GestureDetector(
                  onTap: () {
                    print("پرداخت");
                  },
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(5),
                    child: Container(
                      height: 50,
                      width: 200,
                      color: currentpage == 2
                          ? Colors.redAccent[700]
                          : Colors.transparent,
                      child: Center(
                          child: Text(
                        "پرداخت",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: currentpage == 2
                              ? Colors.white
                              : Colors.transparent,
                          fontFamily: 'Vazir',
                          fontSize: 20,
                        ),
                      )),
                    ),
                  ),
                )),
            Padding(
              padding: const EdgeInsets.only(left: 20.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: contain(
                    "مجموع",
                    "1200000" + " " + "تومان",
                    currentpage == 2 ? Colors.grey[700] : Colors.transparent,
                    currentpage == 2 ? Colors.black : Colors.transparent,
                    17.0,
                    16.0),
              ),
            )
          ],
        ),
      ),
    );
  }

  contain(ty, tr, colorty, colortr, sizefonttrs, sizefonttyp) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        SizedBox(
          height: 8,
        ),
        Expanded(
          flex: 2,
          child: Text(ty,
              style: TextStyle(
                  fontFamily: 'Vazir',
                  fontSize: sizefonttyp == "" ? 15 : sizefonttyp,
                  color: colorty == "" ? Colors.black38 : colorty,
                  fontWeight: FontWeight.bold)),
        ),
        Expanded(
          flex: 2,
          child: Text(tr,
              style: TextStyle(
                  fontFamily: 'Vazir',
                  fontSize: sizefonttrs == "" ? 15 : sizefonttrs,
                  color: colortr == "" ? Colors.black87 : colortr,
                  fontWeight: FontWeight.bold)),
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: pages[currentpage],
        floatingActionButton: actionbutton(),
        floatingActionButtonLocation: currentpage == 2
            ? FloatingActionButtonLocation.centerFloat
            : FloatingActionButtonLocation.endFloat,
        bottomNavigationBar: BottomNavyBar(
          showElevation: true,
          itemCornerRadius: 8,
          curve: Curves.easeInOutBack,
          backgroundColor: currentpage == 0
              ? Colors.redAccent[700]
              : currentpage == 1
                  ? Colors.redAccent[700]
                  : currentpage == 2
                      ? Colors.redAccent[700]
                      : Colors.blueAccent[700],
          selectedIndex: currentindex,
          onItemSelected: _changeItem,
          items: [
            BottomNavyBarItem(
              activeColor: Colors.black54,
              icon: Icon(
                Icons.home,
                color: currentpage == 0 ? Colors.white : Colors.black,
              ),
              title: Text(
                'پیشنهادها',
                style: TextStyle(
                    color: Colors.white, fontFamily: 'Vazir', fontSize: 15),
              ),
            ),
            BottomNavyBarItem(
              activeColor: Colors.black54,
              icon: Icon(
                Icons.dashboard,
                color: currentpage == 1 ? Colors.white : Colors.black,
              ),
              title: Text(
                'دسته بندی ها',
                style: TextStyle(
                    color: Colors.white, fontFamily: 'Vazir', fontSize: 15),
              ),
            ),
            BottomNavyBarItem(
              activeColor: Colors.black54,
              icon: Icon(
                Icons.shopping_cart,
                color: currentpage == 2 ? Colors.white : Colors.black,
              ),
              title: Text(
                'سبدخرید',
                style: TextStyle(
                    color: Colors.white, fontFamily: 'Vazir', fontSize: 15),
              ),
            ),
            BottomNavyBarItem(
              activeColor: Colors.black54,
              icon: Icon(
                Icons.person_pin,
                color: currentpage == 3 ? Colors.white : Colors.black,
              ),
              title: Text(
                'پروفایل من',
                style: TextStyle(
                    color: Colors.white, fontFamily: 'Vazir', fontSize: 15),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
