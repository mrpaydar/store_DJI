class Search {
  String id;
  String namee;
  String desp;
  String price;

  Search(this.id, this.namee, this.desp, this.price);

  getId() {
    return id;
  }

  getNamee() {
    return namee;
  }

  getDesp() {
    return desp;
  }

  getPrice() {
    return price;
  }
}
