import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:store2/pages/bigdeatial.dart';

import 'package:store2/pages/profile.dart';

class GroupsApp extends StatelessWidget {
  const GroupsApp({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: GroupState(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class GroupState extends StatefulWidget {
  @override
  GroupStateApp createState() => GroupStateApp();
}

class GroupStateApp extends State<GroupState> with TickerProviderStateMixin {
  var change;

  GlobalKey<NavigatorState> scafeldkey = GlobalKey<NavigatorState>();
  var idip;

  List<String> listone = [
    "موبایل وتبلت",
    "لپ تاپ ،کامپیوتر،اداری",
    "صوتی و تصویری",
    "لوازم خانگی",
    "پوشاک،کیف وکفش",
    "زیبایی وبهداشت",
    "سلامت وپزشکی",
    "لوازم خودرو",
    "فرهنگی هنری",
    "کودک ونوزاد",
    "ابزار و ساختمان",
    "غذا و لوازم حیوانات",
  ];
  List<String> phone = [
    "تبلت",
    "گوشی اپل،ایفن",
    "گوشی سامسونگ",
    "گوشی هواوی",
    "گوشی شیائومی",
    "گوشی نوکیا",
    "گوشی ال جی",
    "گوشی اچ تی سی",
    "گوشی سونی",
    "گوشی لنوو",
    "گوشی ایسوس",
    "گوشی  بلک بری",
  ];

  abp(context) {
    return AppBar(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
              top: Radius.circular(13), bottom: Radius.circular(13))),
      actions: <Widget>[
        Container(
          margin: EdgeInsets.all(6),
          width: MediaQuery.of(context).size.width - 15,
          height: 45,
          child: GestureDetector(
            onTap: () {},
            child: ClipRRect(
              borderRadius: BorderRadius.circular(13),
              child: Container(
                color: Colors.grey[200],
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    IconButton(
                        icon: Icon(
                          Icons.search,
                          size: 30,
                          color: Colors.black87,
                        ),
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => Profile()));
                        }),
                    SizedBox(
                      width: 12,
                    ),
                    Text(
                      "جستجو در دیجی کالا",
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 19,
                          fontFamily: 'Vazir'),
                    )
                  ],
                ),
              ),
            ),
          ),
        )
      ],
    );
  }

  firstp(context) {
    return SingleChildScrollView(
      child: SizedBox(
        height: MediaQuery.of(context).size.height,
        child: ListView.builder(
            itemCount: listone.length,
            itemBuilder: (context, index) {
              return InkWell(
                onTap: () {
                  setState(() {
                    idip = listone[index];

                    change = true;
                  });
                },
                child: Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadiusDirectional.circular(10)),
                  margin: EdgeInsets.all(5),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Container(
                        width: MediaQuery.of(context).size.width,
                        color: Colors.white,
                        height: 70,
                        child: Center(
                          child: Text(
                            listone[index],
                            style: TextStyle(
                                color: Colors.black54,
                                fontSize: 19,
                                fontFamily: 'Vazir',
                                fontWeight: FontWeight.bold),
                          ),
                        )),
                  ),
                ),
              );
            }),
      ),
    );
  }
  ///// selectfromfor_getAllproduct(getid){
  ///////////dastorat database select baray getid daryafti
  ///agar gender dasht be tabe
  ///daryaft gender va
  ////// first(productlist[index], context)
  //// }

  ///// selectfromfor_getidproductselected(getid){
  ///////////dastorat database select baray getid daryafti
  ///
  ///
  ////// secondp(productlist[index], context)
  //// }

  changepage() {
    if (change == true) {
      setState(() {
        change = false;
      });
    } else {
      SystemNavigator.pop();
    }
  }

  secondp(context, idd) {
    return SingleChildScrollView(
      child: SizedBox(
        height: MediaQuery.of(context).size.height,
        child: ListView.builder(
            itemCount: phone.length,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () {
                  setState(() {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => BigDeatial()));
                  });
                },
                child: Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadiusDirectional.circular(10)),
                  margin:
                      EdgeInsets.only(left: 20, right: 20, top: 10, bottom: 10),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: 75,
                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                                color: listone[index] == "کفش"
                                    ? Colors.redAccent[400]
                                    : listone[index] == "کیف"
                                        ? Colors.blueAccent
                                        : listone[index] == "عمده"
                                            ? Colors.deepOrange
                                            : listone[index] == "عمده فروشی"
                                                ? Colors.indigo
                                                : listone[index] == "مدوپوشاک"
                                                    ? Colors.pink
                                                    : listone[index] ==
                                                            "مدوپوشاک"
                                                        ? Colors.teal
                                                        : listone[index] ==
                                                                "کفشها"
                                                            ? Colors
                                                                .indigoAccent
                                                            : Colors.pink),
                          ),
                          Align(
                              alignment: Alignment.center,
                              child: Text(
                                listone[index],
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 19,
                                    fontFamily: 'Vazir',
                                    fontWeight: FontWeight.bold),
                              )),
                          Align(
                            alignment: Alignment.centerRight,
                            child: Container(
                              height: MediaQuery.of(context).size.height,
                              width: 100,
                              color: Colors.blueAccent,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    change = false;
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: WillPopScope(
        onWillPop: () => changepage(),
        child: Scaffold(
          backgroundColor: Colors.grey[300],
          key: scafeldkey,
          appBar: abp(context),
          body: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                change == false ? firstp(context) : secondp(context, idip)
              ],
            ),
          ),
        ),
      ),
    );
  }
}
