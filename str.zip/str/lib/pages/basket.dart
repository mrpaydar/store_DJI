import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:store2/pages/profile.dart';

class BasketApp extends StatelessWidget {
  const BasketApp({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: AppBasket(),
    );
  }
}

class AppBasket extends StatefulWidget {
  AppBasket({Key key}) : super(key: key);

  @override
  _AppBasketState createState() => _AppBasketState();
}

class _AppBasketState extends State<AppBasket> {
  var counter = 1;

  List<String> images = [
    'http://192.168.198.1/img/as.jpg',
    'http://192.168.198.1/img/b.jpg',
    'http://192.168.198.1/img/c.jpg',
    'http://192.168.198.1/img/d.jpg',
  ];

  bodymain(context) {
    return SingleChildScrollView(
      physics: ScrollPhysics(),
      child: Column(
        children: <Widget>[
          Container(
            width: MediaQuery.of(context).size.width,
            height: 120,
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.only(top: 10.0),
              child: GestureDetector(
                onTap: () {
                  setState(() {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => Profile()));
                  });
                },
                child: Stack(
                  children: <Widget>[
                    Text(
                      " ارسال به  ",
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 16,
                          fontFamily: 'Vazir'),
                    ),
                    Align(
                      alignment: Alignment.center,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Icon(
                            Icons.location_on,
                            size: 23,
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width * 0.7,
                            height: 90,
                            child: Center(
                              child: RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                      text:
                                          "یاسوج خیابان دادگستری قدیم نبش شهدای یک مرکز شهر ساختمان شیلات واحد 1 پلایک 25",
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontFamily: 'Vazir',
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold))),
                            ),
                          ),
                          Icon(Icons.arrow_forward_ios)
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
          ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: images.length,
              itemBuilder: (context, index) {
                return Card(
                  margin: EdgeInsets.only(top: 6.0, bottom: 6.0),
                  color: Colors.white,
                  child: Container(
                    margin: EdgeInsets.all(10),
                    width: MediaQuery.of(context).size.width,
                    height: 350,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Container(
                              width: 180,
                              height: 220,
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      fit: BoxFit.cover,
                                      image: NetworkImage(
                                          'http://192.168.198.1/img/bb.jpg'))),
                            ),
                            Card(
                              elevation: 8.0,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0)),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
                                  IconButton(
                                      icon: Icon(Icons.add),
                                      onPressed: () {
                                        if (counter > 0) {
                                          setState(() {
                                            counter += 1;
                                            print(counter);
                                          });
                                        }
                                      }),
                                  Text(
                                    "$counter",
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontFamily: 'Vazir',
                                        fontSize: 17,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  IconButton(
                                      icon: counter == 1 || counter == 0
                                          ? Icon(
                                              Icons.delete,
                                              color: Colors.redAccent[400],
                                            )
                                          : Icon(Icons.remove),
                                      onPressed: () {
                                        if (counter > 0) {
                                          setState(() {
                                            counter -= 1;
                                            print(counter);
                                          });
                                        }
                                        if (counter < 1) {
                                          setState(() {
                                            images.removeAt(index);
                                          });
                                        }
                                      }),
                                ],
                              ),
                            ),
                            contain(
                              "28540000",
                              "تومان تخفیف " + " ",
                              Colors.redAccent[400],
                              Colors.redAccent[400],
                              13.0,
                              13.0,
                            ),
                            contain(
                              "25000000",
                              " تومان",
                              Colors.black,
                              Colors.black,
                              17.0,
                              17.0,
                            ),
                            SizedBox(
                              height: 10,
                            )
                          ],
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              width: MediaQuery.of(context).size.width * 0.56,
                              height: 60,
                              child: RichText(
                                textAlign: TextAlign.center,
                                text: TextSpan(
                                  text:
                                      " گوشی سامسونگ نود هفتاد وارد شده از کره جنوبی بابهترین کیفیت",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontFamily: 'Vazir',
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                            containtt(
                                "گارانتی 12 ماهه",
                                Icons.assignment_turned_in,
                                Colors.grey[700],
                                Colors.grey[900],
                                14.0,
                                20.0),
                            containtt("لوازم خانگی هرمزی", Icons.store,
                                Colors.grey[700], Colors.grey[900], 14.0, 20.0),
                            containtt(
                                "موجود در انبار دیجی",
                                Icons.offline_pin,
                                Colors.grey[700],
                                Colors.greenAccent[700],
                                14.0,
                                20.0),
                            containtt("ارسال توسط دیجی", Icons.trending_up,
                                Colors.grey[700], Colors.grey[900], 14.0, 20.0),
                            SizedBox(
                              height: 50,
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                );
              }),
          Container(
            width: MediaQuery.of(context).size.width,
            height: 300,
            color: Colors.white,
            child: Column(
              children: <Widget>[
                sabad(
                    "خلاصه سبد",
                    Colors.black87,
                    18.0,
                    FontWeight.bold,
                    "$counter" + " " + "کالا",
                    Colors.grey[600],
                    15.0,
                    FontWeight.normal),
                SizedBox(
                  height: 20,
                ),
                sabad(
                    "مبلغ کل کالاها",
                    Colors.grey[800],
                    16.0,
                    FontWeight.normal,
                    "8000000000" + " " + "تومان",
                    Colors.black,
                    16.0,
                    FontWeight.bold),
                counter > 5
                    ? sabad(
                        "سود شما از خرید",
                        Colors.grey[900],
                        16.0,
                        FontWeight.normal,
                        "25000000" + " " + "تومان",
                        Colors.redAccent[400],
                        16.0,
                        FontWeight.bold)
                    : divider(),
                sabad(
                    "جمع سبد",
                    Colors.grey[900],
                    16.0,
                    FontWeight.normal,
                    "80000000000" + " " + "تومان",
                    Colors.black,
                    16.0,
                    FontWeight.bold),
                divider(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    sabad(
                        "امتیاز در دیجی کلاب",
                        Colors.grey[900],
                        15.0,
                        FontWeight.normal,
                        "",
                        Colors.grey,
                        5.0,
                        FontWeight.normal),
                    Padding(
                      padding: const EdgeInsets.only(left: 10.0),
                      child: Row(
                        children: <Widget>[
                          Text(
                            ("$counter"),
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 17.0,
                            ),
                          ),
                          SizedBox(
                            width: 8,
                          ),
                          Icon(
                            Icons.monetization_on,
                            size: 25.0,
                            color: Colors.amber[900],
                          )
                        ],
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
          Container(
            height: 180,
            width: MediaQuery.of(context).size.width,
            color: Colors.white70,
            child: Align(
              alignment: Alignment.topCenter,
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                    style: TextStyle(
                      color: Colors.grey[900],
                      fontFamily: 'Vazir',
                      fontSize: 17.0,
                    ),
                    text:
                        "کالاهای موجود در سبد خرید شما هنوز ثبت و رزرو نشده اند برای ثبت سفارش مراحل پرداخت راتکمیل بفرمایید"),
              ),
            ),
          )
        ],
      ),
    );
  }

  divider() {
    return Padding(
      padding: const EdgeInsets.only(
          top: 20.0, bottom: 20.0, left: 25.0, right: 25.0),
      child: Divider(
        height: 2,
        color: Colors.grey,
      ),
    );
  }

  sabad(txtone, colorone, sizeone, bo, txttwo, colortwo, sizetwo, bt) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Text(
            txtone,
            style: TextStyle(
                color: colorone,
                fontFamily: 'Vazir',
                fontSize: sizeone,
                fontWeight: bo),
          ),
          Text(
            txttwo,
            style: TextStyle(
                color: colortwo,
                fontFamily: 'Vazir',
                fontSize: sizetwo,
                fontWeight: bt),
          ),
        ],
      ),
    );
  }

  containtt(
    ty,
    ic,
    colorty,
    coloric,
    sizefont,
    sizeic,
  ) {
    return Padding(
      padding: const EdgeInsets.only(right: 10.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          Icon(
            ic,
            color: coloric,
            size: sizeic,
          ),
          SizedBox(
            width: 8.0,
          ),
          Text(ty,
              style: TextStyle(
                  fontFamily: 'Vazir',
                  fontSize: sizefont == "" ? 15 : sizefont,
                  color: colorty == "" ? Colors.black38 : colorty,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  contain(
    ty,
    tr,
    colorty,
    colortr,
    sizefont,
    fontsizetr,
  ) {
    return RichText(
        text: TextSpan(
      children: <TextSpan>[
        TextSpan(
            text: ty,
            style: TextStyle(
                fontFamily: 'Vazir',
                fontSize: fontsizetr == "" ? 15 : fontsizetr,
                color: colorty == "" ? Colors.black38 : colorty,
                fontWeight: FontWeight.bold)),
        TextSpan(
            text: tr,
            style: TextStyle(
                fontFamily: 'Vazir',
                fontSize: sizefont == "" ? 15 : sizefont,
                color: colortr == "" ? Colors.black87 : colortr,
                fontWeight: FontWeight.bold))
      ],
    ));
  }

  bodyempty() {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Icon(
              Icons.remove_shopping_cart,
              size: 38,
            ),
            Text(
              "سبد خرید شما خالی است",
              style: TextStyle(
                color: Colors.grey[800],
                fontFamily: 'Vazir',
                fontSize: 18,
              ),
            )
          ],
        ),
      ),
    );
  }

  AppBar barapp() {
    return AppBar(
      backgroundColor: Colors.white,
      title: Text(
        "سبد خرید",
        style: TextStyle(
          color: Colors.redAccent[400],
          fontFamily: 'Vazir',
          fontSize: 18,
        ),
      ),
      centerTitle: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
          appBar: barapp(),
          backgroundColor: Colors.grey[300],
          body: bodymain(context)),
    );
  }
}
