import 'package:carousel_slider/carousel_controller.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'package:store2/animations/animations.dart';
import 'package:store2/pages/inproduct.dart';
import 'package:store2/pages/profile.dart';
import 'package:store2/pages/search.dart';

class HomeApp extends StatelessWidget {
  const HomeApp({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeState(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeState extends StatefulWidget {
  @override
  HomeAppState createState() => HomeAppState();
}

class HomeAppState extends State<HomeState> {
  static final GlobalKey<ScaffoldState> _scaffoldkey =
      GlobalKey<ScaffoldState>();

  bool expanded = true;

  AnimationController controller;

  PageController pageController;
  PageController pgcontroller;

  List<String> images = [
    'http://192.168.198.1/img/as.jpg',
    'http://192.168.198.1/img/b.jpg',
    'http://192.168.198.1/img/c.jpg',
    'http://192.168.198.1/img/d.jpg',
    'http://192.168.198.1/img/e.jpg',
    'http://192.168.198.1/img/f.jpg',
    'http://192.168.198.1/img/g.jpg',
    'http://192.168.198.1/img/h.jpg',
    'http://192.168.198.1/img/aa.jpg',
    'http://192.168.198.1/img/bb.jpg',
    'http://192.168.198.1/img/cc.jpg',
    'http://192.168.198.1/img/dd.jpg',
  ];

  shegeft(context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: <Widget>[
        Padding(
          padding:
              const EdgeInsets.only(left: 5, right: 10, top: 30, bottom: 3),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text(
                "تخفیفات شگفت انگیز",
                style: TextStyle(
                    fontFamily: 'Vazir',
                    fontSize: 19,
                    fontWeight: FontWeight.bold),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => INPRODUCT()));
                },
                child: Text(
                  "نمایش همه > ",
                  style: TextStyle(
                      fontFamily: 'Vazir',
                      fontSize: 16,
                      color: Colors.redAccent[400],
                      fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
        Container(
            width: MediaQuery.of(context).size.width,
            height: 420,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.centerRight,
                    end: Alignment.topLeft,
                    colors: [Colors.redAccent[700], Colors.redAccent[200]])),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  SizedBox(
                    width: 23,
                  ),
                  Container(
                    width: 170,
                    height: 400,
                    child: Center(
                      child: Image(
                          image:
                              NetworkImage('http://192.168.198.1/img/g.jpg')),
                    ),
                  ),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    itemCount: 6,
                    itemBuilder: ((context, index) {
                      return GestureDetector(
                        onTap: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => INPRODUCT()));
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Card(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Container(
                                  height: 350,
                                  width: 180,
                                  color: Colors.white,
                                  child: Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(10),
                                        child: Container(
                                          width:
                                              MediaQuery.of(context).size.width,
                                          height: 200,
                                          decoration: BoxDecoration(
                                              image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: NetworkImage(
                                                      images[index]))),

                                          ///child:network image ,
                                        ),
                                      ),
                                      Text(
                                        "نام کالا",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontSize: 17,
                                          fontFamily: 'Vazir',
                                        ),
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: <Widget>[
                                          ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            child: Container(
                                              width: 40,
                                              height: 23,
                                              color: Colors.red,
                                              child: Center(
                                                child: Text("20%",
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        color: Colors.white,
                                                        fontSize: 17,
                                                        fontFamily: 'Vazir')),
                                              ),
                                            ),
                                          ),
                                          Text("مبلغ تومان",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 17,
                                                  fontFamily: 'Vazir'))
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }),
                  ),
                  GestureDetector(
                    onTap: () {},
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        color: Colors.white,
                        width: 180,
                        height: 350,
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Icon(Icons.arrow_forward),
                              Text(
                                "نمایش همه  ",
                                style: TextStyle(
                                    fontFamily: 'Vazir',
                                    fontSize: 16,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 8,
                  )
                ],
              ),
            )),
      ],
    );
  }

  txtmian(value, cs, bl) {
    return Padding(
      padding: const EdgeInsets.only(right: 10, left: 8),
      child: Row(
        mainAxisAlignment:
            cs == "center" ? MainAxisAlignment.center : MainAxisAlignment.start,
        children: <Widget>[
          Text(
            value,
            style: TextStyle(
                fontFamily: 'Vazir',
                fontSize: 18,
                fontWeight: bl == "b" ? FontWeight.bold : FontWeight.normal),
          ),
        ],
      ),
    );
  }

  shegefttwo(context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: <Widget>[
        Padding(
          padding:
              const EdgeInsets.only(left: 5, right: 10, top: 30, bottom: 3),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text(
                "شگفت انگیزهای عمده",
                style: TextStyle(
                    fontFamily: 'Vazir',
                    fontSize: 19,
                    fontWeight: FontWeight.bold),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => INPRODUCT()));
                },
                child: Text(
                  "نمایش همه > ",
                  style: TextStyle(
                      fontFamily: 'Vazir',
                      fontSize: 16,
                      color: Colors.greenAccent[700],
                      fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
        Container(
            width: MediaQuery.of(context).size.width,
            height: 420,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.centerRight,
                    end: Alignment.topLeft,
                    colors: [
                  Colors.green[700].withOpacity(0.9),
                  Colors.greenAccent[400]
                ])),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  SizedBox(
                    width: 23,
                  ),
                  Container(
                    width: 170,
                    height: 400,
                    child: Center(
                      child: Image(
                          image:
                              NetworkImage('http://192.168.198.1/img/g.jpg')),
                    ),
                  ),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    itemCount: 6,
                    itemBuilder: ((context, index) {
                      return GestureDetector(
                        onTap: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => INPRODUCT()));
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Card(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Container(
                                  height: 350,
                                  width: 180,
                                  color: Colors.white,
                                  child: Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(10),
                                        child: Container(
                                          width:
                                              MediaQuery.of(context).size.width,
                                          height: 200,
                                          decoration: BoxDecoration(
                                              image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: NetworkImage(
                                                      images[index]))),

                                          ///child:network image ,
                                        ),
                                      ),
                                      Text(
                                        "نام کالا",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontSize: 17,
                                          fontFamily: 'Vazir',
                                        ),
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: <Widget>[
                                          ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            child: Container(
                                              width: 40,
                                              height: 23,
                                              color: Colors.red,
                                              child: Center(
                                                child: Text("20%",
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        color: Colors.white,
                                                        fontSize: 17,
                                                        fontFamily: 'Vazir')),
                                              ),
                                            ),
                                          ),
                                          Text("مبلغ تومان",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 17,
                                                  fontFamily: 'Vazir'))
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }),
                  ),
                  GestureDetector(
                    onTap: () {},
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        color: Colors.white,
                        width: 180,
                        height: 350,
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Icon(Icons.arrow_forward),
                              Text(
                                "نمایش همه  ",
                                style: TextStyle(
                                    fontFamily: 'Vazir',
                                    fontSize: 16,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 8,
                  )
                ],
              ),
            )),
      ],
    );
  }

  containerr(c, i) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(45),
      child: Container(
        width: 60,
        height: 60,
        color: c, //lightBlueAccent[400],
        child: Icon(
          i,
          size: 28,
        ),
      ),
    );
  }

  Widget designproduct(context) {
    return Padding(
      padding: const EdgeInsets.only(left: 40, right: 40),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          GestureDetector(
            onTap: () {
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) => INPRODUCT()));
            },
            child: Column(
              children: <Widget>[
                containerr(
                  Colors.redAccent[400],
                  Icons.tv,
                ),
                Text(
                  "لوازم خانگی",
                  style: TextStyle(fontFamily: 'Vazir'),
                )
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) => INPRODUCT()));
            },
            child: Column(
              children: <Widget>[
                containerr(Colors.purple[500], Icons.access_time),
                Text(
                  "ساعت و عطر",
                  style: TextStyle(fontFamily: 'Vazir'),
                )
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) => INPRODUCT()));
            },
            child: Column(
              children: <Widget>[
                containerr(
                  Colors.greenAccent[700],
                  Icons.accessibility,
                ),
                Text(
                  "مدوپوشاک",
                  style: TextStyle(fontFamily: 'Vazir'),
                )
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) => INPRODUCT()));
            },
            child: Column(
              children: <Widget>[
                containerr(
                  Colors.lightBlueAccent[400],
                  Icons.phone_android,
                ),
                Text(
                  "لوازم الکترونیک",
                  style: TextStyle(fontFamily: 'Vazir'),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  watingview() {
    return Padding(
      padding: const EdgeInsets.only(top: 320),
      child: SpinKitThreeBounce(
        color: Colors.redAccent[400],
        size: 25,
      ),
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  Widget pageView() {
    return CarouselSlider.builder(
        itemCount: images.length,
        itemBuilder: (context, index) {
          return ClipRRect(
            borderRadius: BorderRadius.circular(5),
            child: Container(
              width: 350,
              height: 200,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      fit: BoxFit.cover, image: NetworkImage(images[index])),
                  gradient: LinearGradient(
                      begin: Alignment.centerRight,
                      end: Alignment.centerLeft,
                      colors: [
                        Colors.blueAccent[400],
                        Colors.blueAccent[400].withOpacity(0.5)
                      ])),
            ),
          );
        },
        options: CarouselOptions(
          height: 200,
          viewportFraction: 0.75,
          initialPage: 1,
          enableInfiniteScroll: true,
          reverse: true,
          autoPlay: true,
          autoPlayInterval: Duration(milliseconds: 4800),
          autoPlayAnimationDuration: Duration(milliseconds: 3000),
          autoPlayCurve: Curves.easeInOut,
          enlargeCenterPage: false,
          scrollDirection: Axis.horizontal,
        ));
  }

  Widget pagedesign(context) {
    return CarouselSlider.builder(
        itemCount: images.length,
        itemBuilder: (context, int index) {
          return ClipRRect(
            borderRadius: BorderRadius.circular(5),
            child: GestureDetector(
              onTap: () {
                print(index);
              },
              child: Stack(
                children: <Widget>[
                  Container(
                    width: 200,
                    height: 150,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          fit: BoxFit.fill, image: NetworkImage(images[index])),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10, right: 8),
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: ClipRRect(
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(25),
                        ),
                        child: Container(
                          width: 200,
                          height: 25,
                          decoration: BoxDecoration(
                              gradient: LinearGradient(
                                  begin: Alignment.centerRight,
                                  end: Alignment.centerLeft,
                                  colors: [Colors.black54, Colors.black26])),
                          child: Text(
                            "ساعت البرز",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: Colors.white,
                                fontFamily: 'Vazir',
                                fontSize: 17),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
        options: CarouselOptions(
          height: 150,
          aspectRatio: 10,
          viewportFraction: 0.4,
          initialPage: 1,
          enableInfiniteScroll: true,
          reverse: true,
          autoPlay: true,
          autoPlayInterval: Duration(seconds: 3),
          autoPlayAnimationDuration: Duration(milliseconds: 1500),
          autoPlayCurve: Curves.easeInOut,
          enlargeCenterPage: true,
          scrollDirection: Axis.horizontal,
        ));
  }

  Widget nemadelecktro(context) {
    return SizedBox(
      height: 95,
      child: CarouselSlider.builder(
          itemCount: images.length,
          itemBuilder: (context, int index) {
            return GestureDetector(
              onTap: () {
                print(index);
              },
              child: Container(
                width: 100,
                height: 80,
                decoration: BoxDecoration(
                  image: DecorationImage(
                      fit: BoxFit.cover, image: NetworkImage(images[index])),
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10),
                      bottomLeft: Radius.circular(10),
                      bottomRight: Radius.circular(10)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.4),
                      spreadRadius: 5,
                      blurRadius: 4,
                      offset: Offset(0, 1), // changes position of shadow
                    ),
                  ],
                ),
              ),
            );
          },
          options: CarouselOptions(
            height: 80,
            viewportFraction: 0.3,
            initialPage: 1,
            enableInfiniteScroll: true,
            reverse: true,
            enlargeCenterPage: true,
            autoPlay: false,
            autoPlayCurve: Curves.easeInOut,
            scrollDirection: Axis.horizontal,
          )),
    );
  }

  abp(context) {
    return AppBar(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
              top: Radius.circular(13), bottom: Radius.circular(13))),
      actions: <Widget>[
        Container(
          margin: EdgeInsets.all(6),
          width: MediaQuery.of(context).size.width - 15,
          height: 45,
          child: GestureDetector(
            onTap: () {},
            child: ClipRRect(
              borderRadius: BorderRadius.circular(13),
              child: Container(
                color: Colors.grey[200],
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    IconButton(
                        icon: Icon(
                          Icons.search,
                          size: 30,
                          color: Colors.black87,
                        ),
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => ToolbarSearch()));
                        }),
                    SizedBox(
                      width: 12,
                    ),
                    Text(
                      "جستجو در دیجی کالا",
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 19,
                          fontFamily: 'Vazir'),
                    )
                  ],
                ),
              ),
            ),
          ),
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          key: _scaffoldkey,
          appBar: abp(context),
          body: Directionality(
            textDirection: TextDirection.rtl,
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  SizedBox(
                    height: 20,
                  ),
                  pageView(),
                  SizedBox(
                    height: 20,
                  ),
                  designproduct(context),
                  SizedBox(
                    height: 10,
                  ),
                  shegeft(context),
                  SizedBox(
                    height: 10,
                  ),
                  shegefttwo(context),
                  SizedBox(
                    height: 30,
                  ),
                  txtmian("پیشنهادهای فروشگاه", "", "b"),
                  SizedBox(
                    height: 10,
                  ),
                  pagedesign(context),
                  SizedBox(
                    height: 20,
                  ),
                  txtmian("امنیت فروشگاه", "center", ""),
                  nemadelecktro(context),
                  SizedBox(
                    height: 20,
                  ),
                ],
              ),
            ),
          ),
        ));
  }
}
