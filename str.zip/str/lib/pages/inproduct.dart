import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:store2/pages/bigdeatial.dart';

class INPRODUCT extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Inpro(),
    );
  }
}

class Inpro extends StatefulWidget {
  Inpro({Key key}) : super(key: key);

  @override
  _InproState createState() => _InproState();
}

class _InproState extends State<Inpro> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () => Navigator.of(context)
          .push(MaterialPageRoute(builder: (context) => BigDeatials())),
      child: Scaffold(
        body: Center(
          child: Text(
            "اطلاعات مربوط به کالا",
            style: TextStyle(fontFamily: 'Vazir', fontSize: 24),
          ),
        ),
      ),
    );
  }
}
