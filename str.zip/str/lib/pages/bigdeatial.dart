import 'dart:developer';

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/animation.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';

class BigDeatials extends StatelessWidget {
  const BigDeatials({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: BigDeatial(),
    );
  }
}

class BigDeatial extends StatefulWidget {
  BigDeatial({Key key}) : super(key: key);

  @override
  _BigDeatialState createState() => _BigDeatialState();
}

class mycliperr extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();

    path.moveTo(0, 0);
    path.quadraticBezierTo(size.width / 2, 80, size.width, 0);
    path.lineTo(size.width, 0);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}

class _BigDeatialState extends State<BigDeatial> with TickerProviderStateMixin {
  AnimationController controller;
  AnimationController _tabcontroller;
  bool buycart;
  bool change;
  var isactive;
  double _scale;
  bool showdeatial = false;
  double wid = 33;
  double hid = 33;
  int counter = 0;

  List<String> images = [
    'http://192.168.198.1/img/as.jpg',
    'http://192.168.198.1/img/b.jpg',
    'http://192.168.198.1/img/c.jpg',
    'http://192.168.198.1/img/d.jpg',
    'http://192.168.198.1/img/e.jpg',
    'http://192.168.198.1/img/f.jpg',
    'http://192.168.198.1/img/g.jpg',
    'http://192.168.198.1/img/h.jpg',
    'http://192.168.198.1/img/aa.jpg',
    'http://192.168.198.1/img/bb.jpg',
    'http://192.168.198.1/img/cc.jpg',
    'http://192.168.198.1/img/dd.jpg',
  ];

  contain(ty, tr, colorty, colortr, sizefont) {
    return Padding(
      padding: const EdgeInsets.only(top: 15, bottom: 15, left: 8, right: 8),
      child: RichText(
          text: TextSpan(
        children: <TextSpan>[
          TextSpan(
              text: ty,
              style: TextStyle(
                  fontFamily: 'Vazir',
                  fontSize: 15,
                  color: colorty == "" ? Colors.black38 : colorty,
                  fontWeight: FontWeight.bold)),
          TextSpan(
              text: tr,
              style: TextStyle(
                  fontFamily: 'Vazir',
                  fontSize: sizefont == "" ? 15 : sizefont,
                  color: colortr == "" ? Colors.black87 : colortr,
                  fontWeight: FontWeight.bold))
        ],
      )),
    );
  }

  bigdeitals() {
    return CustomScrollView(
      slivers: <Widget>[
        SliverAppBar(
          backgroundColor: Colors.redAccent[400],
          expandedHeight: 130,
          elevation: 10,
          floating: false,
          pinned: true,
          flexibleSpace: FlexibleSpaceBar(
            centerTitle: true,
            title: AnimatedBuilder(
              animation: controller,
              builder: (context, widget) {
                return ShaderMask(
                  shaderCallback: (rect) {
                    return LinearGradient(colors: [
                      Colors.grey[400],
                      Colors.white,
                      Colors.grey[400]
                    ], stops: [
                      controller.value - 0.3,
                      controller.value,
                      controller.value + 0.3
                    ]).createShader(
                        Rect.fromLTWH(0, 0, rect.width, rect.height));
                  },
                  child: Text(
                    "محصولات خوش بو کننده  ",
                    style: TextStyle(
                      fontSize: 17,
                      fontFamily: 'Vazir',
                    ),
                  ),
                  blendMode: BlendMode.srcIn,
                );
              },
            ),
            background: Container(
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [Colors.redAccent[700], Colors.redAccent[200]])),
            ),
          ),
          actions: <Widget>[
            ClipRRect(
              borderRadius: BorderRadius.circular(50),
              child: AnimatedContainer(
                duration: Duration(milliseconds: 500),
                width: buycart ? wid : 0,
                height: buycart ? hid : 0,
                child: Column(
                  children: <Widget>[
                    Text(
                      "$counter",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.bold),
                    ),
                    Icon(
                      Icons.shopping_cart,
                      color: Colors.white,
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
        SliverGrid(
          gridDelegate:
              SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
          delegate: SliverChildBuilderDelegate((context, index) {
            return GestureDetector(
              onTap: () {
                setState(() {
                  change = true;
                });
              },
              child: Container(
                  margin: EdgeInsets.all(4),
                  width: 150,
                  height: 200,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6),
                      gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.white70, Colors.white70])),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: 200,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6),
                        image: DecorationImage(
                            fit: BoxFit.cover,
                            image: NetworkImage(images[index]))),
                  )),
            );
          }, childCount: images.length),
        ),
      ],
    );
  }

  topcontin(ic, col, addremov) {
    return GestureDetector(
      onTap: () {
        if (addremov == 1) {
          setState(() {
            buycart = true;
            counter += 1;
          });
        }
        if (addremov == 0 && buycart == true) {
          setState(() {
            counter -= 1;
          });
        }
        if (addremov == 0 && counter == 0) {
          setState(() {
            buycart = false;
          });
        }

        print(counter);
      },
      onTapDown: _ontapdown,
      onTapUp: _ontapup,
      child: Transform.scale(
        scale: _scale,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 30,
            height: 30,
            color: col,
            child: Center(
              child: Icon(
                ic,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }

  onedetial() {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: SingleChildScrollView(
        physics: ScrollPhysics(),
        child: SizedBox(
          height: 1200,
          width: MediaQuery.of(context).size.width,
          child: Stack(
            children: <Widget>[
              ClipPath(
                clipper: OvalBottomBorderClipper(),
                child: CarouselSlider.builder(
                  itemCount: images.length,
                  itemBuilder: ((context, index) {
                    return Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              fit: BoxFit.cover,
                              image: NetworkImage(images[index]))),
                    );
                  }),
                  options: CarouselOptions(
                    viewportFraction: 1,
                    initialPage: 0,
                    enableInfiniteScroll: true,
                    reverse: true,
                    height: 240,
                    autoPlay: true,
                    autoPlayInterval: Duration(milliseconds: 4500),
                    autoPlayAnimationDuration: Duration(milliseconds: 3000),
                    autoPlayCurve: Curves.easeInOut,
                    enlargeCenterPage: false,
                    scrollDirection: Axis.horizontal,
                  ),
                ),
              ),
              Positioned(
                top: 250,
                right: MediaQuery.of(context).size.width / 2 - 170,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text(
                      " فروشگاه هرمزی",
                      style: TextStyle(
                          fontFamily: 'Vazir',
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87),
                    ),
                    Text(
                      " شماره تماس : 09172961002",
                      style: TextStyle(
                          fontFamily: 'Vazir',
                          fontSize: 16,
                          color: Colors.black87),
                    ),
                    Text(
                      " ادرس : یاسوج خیابان پزشک روبروی داروخانه دکتر نیکبخت",
                      style: TextStyle(
                          fontFamily: 'Vazir',
                          fontSize: 15,
                          color: Colors.black87),
                    )
                  ],
                ),
              ),
              AnimatedPositioned(
                  bottom: showdeatial ? -150 : 0,
                  child: ClipPath(
                    clipper: mycliperr(),
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: 1000,
                      decoration: BoxDecoration(
                          color: Colors.grey[200].withOpacity(0.9)),
                      child: Align(
                        alignment: Alignment.topCenter,
                        child: Stack(
                          children: <Widget>[
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                SizedBox(
                                  height: 110,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(right: 12),
                                  child: Text(
                                    "سایز بندی",
                                    style: TextStyle(
                                      fontSize: 17,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Vazir',
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width,
                                  child: ListView.builder(
                                      shrinkWrap: true,
                                      scrollDirection: Axis.horizontal,
                                      itemCount: images.length,
                                      itemBuilder: (context, index) {
                                        return GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              isactive = images[index];
                                            });
                                          },
                                          child: Card(
                                            elevation: 5,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(12)),
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                              child: Container(
                                                width: 98,
                                                height: 48,
                                                color: isactive == images[index]
                                                    ? Colors.greenAccent[400]
                                                        .withOpacity(0.7)
                                                    : Colors.white10,
                                              ),
                                            ),
                                          ),
                                        );
                                      }),
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Card(
                                  margin: EdgeInsets.only(
                                      left: 25, right: 25, top: 10, bottom: 10),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12)),
                                  elevation: 15,
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(12),
                                    child: Container(
                                        width:
                                            MediaQuery.of(context).size.width,
                                        height: 500,
                                        child: SizedBox(
                                            height: 480,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: <Widget>[
                                                contain(
                                                    "نام کالا : ",
                                                    "تلویزیون سامسونگ مدلXCGFJ",
                                                    "",
                                                    "",
                                                    ""),
                                                contain(
                                                    "توضیحات : ",
                                                    "این تلویزیوون بارنگ بندی متنوع وکارکرد عالی با طول عمر 25 سال به بالا وگارانتی 3 ساله در خدمت شما عزیزان ممیباشدامیدوارم که کیفیت کالاهای مارا پسندیده باشید",
                                                    "",
                                                    "",
                                                    ""),
                                                contain(
                                                    "کد کالا : ",
                                                    "EP723515401111111111111101",
                                                    "",
                                                    "",
                                                    ""),
                                                Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    contain(
                                                        "قیمت : ",
                                                        "2,000,000 تومان",
                                                        Colors.black87,
                                                        Colors.redAccent,
                                                        16.0),
                                                    contain(
                                                        "قیمت باتخفیف : ",
                                                        "1,800,000 تومان",
                                                        Colors.black87,
                                                        Colors.blueAccent[700],
                                                        16.0),
                                                  ],
                                                )
                                              ],
                                            ))),
                                  ),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Center(
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Container(
                                      width:
                                          (MediaQuery.of(context).size.width /
                                                  2) -
                                              70,
                                      height: 50,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: <Widget>[
                                          topcontin(Icons.add,
                                              Colors.greenAccent[700], 1),
                                          Center(
                                            child: Text(
                                              "تعداد",
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold,
                                                  fontFamily: 'Vazir'),
                                            ),
                                          ),
                                          topcontin(Icons.remove,
                                              Colors.greenAccent[700], 0)
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Center(
                                  child: GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        buycart = true;
                                        counter += 1;
                                        print(counter);
                                      });
                                    },
                                    onTapDown: _ontapdown,
                                    onTapUp: _ontapup,
                                    child: Transform.scale(
                                      scale: _scale,
                                      child: ClipPath(
                                        clipper: mycliperr(),
                                        child: ClipRRect(
                                          borderRadius: BorderRadius.only(
                                              bottomLeft: Radius.circular(90),
                                              bottomRight: Radius.circular(90)),
                                          child: Container(
                                            width: 250,
                                            height: 65,
                                            decoration: BoxDecoration(
                                                gradient: LinearGradient(
                                                    begin: Alignment.topCenter,
                                                    end: Alignment.bottomCenter,
                                                    colors: [
                                                      Colors.greenAccent[400]
                                                          .withOpacity(0.7),
                                                      Colors.greenAccent[700]
                                                    ]),
                                                boxShadow: [
                                                  BoxShadow(
                                                      color: Color(0x80000000),
                                                      blurRadius: 30.0,
                                                      offset: Offset(0.0, 30.0))
                                                ]),
                                            child: Align(
                                              alignment: Alignment.bottomCenter,
                                              child: Text(
                                                "افزودن به سبد خرید",
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontFamily: 'Vazir',
                                                    fontSize: 16,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  duration: Duration(milliseconds: 800)),
              AnimatedPositioned(
                top: showdeatial ? -80 : -15,
                right: (MediaQuery.of(context).size.width) / 2 - 65,
                child: GestureDetector(
                  onTap: () {
                    print("1");
                    setState(() {
                      showdeatial ? showdeatial = false : showdeatial = true;
                    });
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(top: 210),
                    child: Container(
                      width: 110,
                      height: 110,
                      child: Align(
                        alignment: showdeatial
                            ? Alignment.bottomCenter
                            : Alignment.topCenter,
                        child: Icon(showdeatial
                            ? Icons.keyboard_arrow_down
                            : Icons.keyboard_arrow_up),
                      ),
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          image: DecorationImage(
                              fit: BoxFit.cover,
                              image: NetworkImage(
                                  "http://192.168.198.1/img/bb.jpg"))),
                    ),
                  ),
                ),
                duration: Duration(milliseconds: 800),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _ontapdown(TapDownDetails details) {
    _tabcontroller.forward();
  }

  void _ontapup(TapUpDetails details) {
    _tabcontroller.reverse();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    buycart = false;
    change = false;
    DeviceOrientation.portraitUp;
    DeviceOrientation.portraitDown;

    _tabcontroller = AnimationController(
        vsync: this,
        duration: Duration(milliseconds: 200),
        lowerBound: 0.0,
        upperBound: 0.1)
      ..addListener(() {
        setState(() {});
      });

    controller =
        AnimationController(vsync: this, duration: Duration(seconds: 3))
          ..repeat();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _tabcontroller.dispose();
    controller.dispose();
    super.dispose();
  }

  changepage(context) {
    if (change == true) {
      setState(() {
        change = false;
      });
    } else {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    _scale = 1 - _tabcontroller.value;
    return WillPopScope(
        onWillPop: () => changepage(context),
        child: Scaffold(
            backgroundColor: Colors.white,
            body: change == false ? bigdeitals() : onedetial()));
  }
}
