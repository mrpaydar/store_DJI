import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:store2/animations/animations.dart';

import 'package:store2/pages/passpage.dart';

class SignupApp extends StatelessWidget {
  const SignupApp({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SignupState(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class SignupState extends StatefulWidget {
  @override
  SignupAppState createState() => SignupAppState();
}

class SignupAppState extends State<SignupState> {
  bool passvisiable;

  bool visiable = false;
  bool btext = false;

  final GlobalKey<ScaffoldState> _scaffoldkey = GlobalKey<ScaffoldState>();

  final numberkey = GlobalKey<FormState>();
  final passkey = GlobalKey<FormState>();
  final namekey = GlobalKey<FormState>();
  final passwordkey = GlobalKey<FormState>();
  final password2key = GlobalKey<FormState>();

  final textvalue = TextEditingController();
  final passvalue = TextEditingController();
  final namevalue = TextEditingController();
  final passwordvalue = TextEditingController();
  final password2value = TextEditingController();

  double _animatedHeight = 330;
  double _animatedWidth = 350;
  var ii;

  bool _isAnimated = true;

  var url = 'http://192.168.198.1/img/aa.jpg';

  Widget loginForm(context) {
    return Directionality(
        textDirection: TextDirection.rtl,
        child: SingleChildScrollView(
          child: Stack(
            children: <Widget>[
              ClipPath(
                clipper: OvalBottomBorderClipper(),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: 330,
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.cyan, Colors.blueAccent[700]])),
                  child: Align(
                      alignment: Alignment.center,
                      child: Container(
                        width: 180,
                        height: 180,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            image: DecorationImage(
                                fit: BoxFit.cover, image: NetworkImage(url))),
                      )),
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: const EdgeInsets.only(top: 265),
                  child: Container(
                    margin: EdgeInsets.only(bottom: 30),
                    width: 350,
                    height: 330,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10),
                          bottomLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10)),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 5,
                          blurRadius: 7,
                          offset: Offset(0, 3), // changes position of shadow
                        ),
                      ],
                    ),
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          height: 30,
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextFormField(
                            key: numberkey,
                            controller: textvalue,
                            keyboardType: TextInputType.number,
                            maxLength: 11,
                            decoration: InputDecoration(
                              hintText: 'شماره موبایل',
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextFormField(
                            key: passkey,
                            controller: passvalue,
                            obscureText: passvisiable,
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                              hintText: "کلمه عبور ",
                              suffixIcon: IconButton(
                                  icon: Icon(
                                    passvisiable
                                        ? Icons.visibility
                                        : Icons.visibility_off,
                                    size: 20,
                                  ),
                                  onPressed: () {
                                    setState(() {
                                      passvisiable = !passvisiable;
                                    });
                                  }),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 3,
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              ii = 2;
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(left: 215),
                            child: Text(
                              "فراموش کردن رمز عبور",
                              style: TextStyle(
                                  fontFamily: 'Vazir',
                                  color:
                                      Colors.blueAccent[700].withOpacity(0.8)),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(35),
                          child: Container(
                            width: 170,
                            height: 38,
                            color: Colors.blueAccent[700],
                            child: FlatButton(
                              splashColor: Colors.blueAccent[400],
                              onPressed: () {
                                if (textvalue.text != "" &&
                                    passvalue.text != "" &&
                                    textvalue.text.length >= 11) {
                                  login(
                                      textvalue.text, passvalue.text, context);
                                } else {
                                  showMessage(
                                      "شماره همراه وارد شده یا رمز عبور شما معتبر نیست");
                                  return null;
                                }
                              },
                              child: Text(
                                'ورود به فروشگاه',
                                style: TextStyle(
                                  fontFamily: 'Vazir',
                                  color: Colors.white,
                                  fontSize: 17,
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 18,
                        ),
                        GestureDetector(
                            onTap: () {
                              setState(() {
                                ii = 2;
                              });
                            },
                            child: Text(
                              "ثبت نام در فروشگاه",
                              style: TextStyle(
                                fontFamily: 'Vazir',
                                color: Colors.blueAccent[400],
                                fontSize: 16,
                              ),
                            )),
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ));
  }

  Widget signupForm(context) {
    return Directionality(
        textDirection: TextDirection.rtl,
        child: SingleChildScrollView(
          physics: ScrollPhysics(),
          child: Stack(
            children: <Widget>[
              ClipPath(
                clipper: OvalBottomBorderClipper(),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: 330,
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.cyan, Colors.blueAccent[700]])),
                  child: Align(
                      alignment: Alignment.center,
                      child: Container(
                        width: 180,
                        height: 180,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            image: DecorationImage(
                                fit: BoxFit.cover,
                                image: NetworkImage(
                                    'http://192.168.198.1/img/bb.jpg'))),
                      )),
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                    padding: const EdgeInsets.only(top: 265),
                    child: AnimatedContainer(
                      duration: Duration(seconds: 2),
                      margin: EdgeInsets.only(bottom: 30),
                      width: _isAnimated ? _animatedWidth : 350,
                      height: _isAnimated ? _animatedHeight : 440,
                      curve: Curves.fastOutSlowIn,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10),
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 5,
                            blurRadius: 7,
                            offset: Offset(0, 3), // changes position of shadow
                          ),
                        ],
                      ),
                      child: SingleChildScrollView(
                        child: Column(
                          children: <Widget>[
                            SizedBox(
                              height: 10,
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: TextFormField(
                                key: namekey,
                                keyboardType: TextInputType.text,
                                controller: namevalue,
                                textAlign: TextAlign.center,
                                maxLength: 60,
                                decoration: InputDecoration(
                                  labelStyle: TextStyle(
                                    fontSize: 17,
                                  ),
                                  hintText: "نام ونام خانوادگی",
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: TextFormField(
                                key: numberkey,
                                keyboardType: TextInputType.number,
                                controller: textvalue,
                                textAlign: TextAlign.center,
                                maxLength: 11,
                                decoration: InputDecoration(
                                  hintStyle: TextStyle(fontSize: 18),
                                  hintText: 'شماره موبایل',
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: AnimatedContainer(
                                duration: Duration(seconds: 2),
                                width: _isAnimated ? 0 : 120,
                                height: _isAnimated ? 0 : 50,
                                color: Colors.lightGreenAccent[400],
                                child: Align(
                                  alignment: Alignment.bottomCenter,
                                  child: TextFormField(
                                    key: passkey,
                                    controller: passvalue,
                                    textAlign: TextAlign.center,
                                    keyboardType: TextInputType.number,
                                    decoration:
                                        InputDecoration(hintText: "کد موقت"),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(35),
                              child: Container(
                                width: 170,
                                height: 38,
                                color: Colors.blueAccent[700],
                                child: FlatButton(
                                    splashColor: Colors.blueAccent[400],
                                    onPressed: () {
                                      setState(() {
                                        if (textvalue.text == "" ||
                                            textvalue.text.length < 11) {
                                          showMessage(
                                              "شماره موبایل وارد شده معتبر نیست");

                                          _isAnimated = true;
                                        } else {
                                          btext = true;
                                          var txtv = textvalue.text;
                                          showMessage(
                                              "ارسال شد $txtv کدیک بارمصرف به شماره ");
                                          _isAnimated = false;
                                          if (textvalue.text != "" &&
                                              namevalue.text != "" &&
                                              passvalue.text == "") {
                                            signup(textvalue.text,
                                                namevalue.text, context);
                                          }
                                          if (textvalue.text != "" &&
                                              namevalue.text != "" &&
                                              passvalue.text != "") {
                                            verifycode(
                                                textvalue.text,
                                                namevalue.text,
                                                passvalue.text,
                                                context);
                                          }
                                        }
                                      });
                                    },
                                    child: btext
                                        ? Text(
                                            'تایید کد',
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 17,
                                                fontFamily: 'Vazir'),
                                          )
                                        : Text(
                                            'ارسال کد',
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 17,
                                                fontFamily: 'Vazir'),
                                          )),
                              ),
                            ),
                            SizedBox(
                              height: 18,
                            ),
                            GestureDetector(
                                onTap: () {
                                  setState(() {
                                    ii = 1;
                                  });
                                },
                                child: Text(
                                  "قبلا ثبت نام کردم",
                                  style: TextStyle(
                                      color: Colors.blueAccent[400],
                                      fontSize: 16,
                                      fontFamily: 'Vazir'),
                                )),
                          ],
                        ),
                      ),
                    )),
              )
            ],
          ),
        ));
  }

  login(String number, String pass, context) async {
    var url = "https://pearlpaydar.ir/login.php";
    var response =
        await http.post(url, body: {"number": number, "password": pass});
    var logindata = json.decode(response.body);

    if (logindata["status"] == "success") {
      SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();
      sharedPreferences.setString("number", logindata["message"]);

      showMessage("ورود با موفقیت انجام شد");

      setState(() {
        ii = 3;
      });
    }
  }

  profilepage() {
    return SingleChildScrollView(
      child: Container(
        height: 380,
        decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
              Colors.lightBlueAccent[400].withOpacity(0.8),
              Colors.blueAccent[400]
            ])),
        child: Stack(
          children: <Widget>[
            Align(
              alignment: Alignment.topCenter,
              child: Padding(
                padding: const EdgeInsets.only(top: 8, right: 10),
                child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      image: DecorationImage(
                          fit: BoxFit.cover, image: NetworkImage(""))),
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.only(top: 16, bottom: 23),
                child: Text(
                  " شماره",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.white70,
                      fontSize: 17,
                      fontFamily: 'Vazir',
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Text(
                "نمایش پروفایل",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontFamily: 'Vazir', color: Colors.white70, fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }

  verifycode(String number, String name, String code, context) {
    return Navigator.of(context)
        .push(CupertinoPageRoute(builder: (context) => PassPage()));
  }

  signup(String number, String name, context) {}

  showMessage(String value) {
    _scaffoldkey.currentState.showSnackBar(SnackBar(
      behavior: SnackBarBehavior.floating,
      elevation: 6.0,
      duration: Duration(milliseconds: 800),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      content: Text(
        value,
        textAlign: TextAlign.center,
        style:
            TextStyle(fontFamily: 'Vazir', fontSize: 18, color: Colors.white),
      ),
    ));
  }

  @override
  void initState() {
    super.initState();
    passvisiable = false;

    iivalue();
  }

  iivalue() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    String number = sharedPreferences.getString("number");

    if (number != null) {
      setState(() {
        ii = 3;
      });
    } else {
      setState(() {
        ii = 1;
      });
    }
  }

  baner(context) {
    return ClipPath(
      clipper: OvalBottomBorderClipper(),
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: 350,
        decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.cyan, Colors.blueAccent[700]])),
        child: Align(
            alignment: Alignment.center,
            child: Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    fit: BoxFit.cover,
                    image: NetworkImage('http://192.168.198.1/img/aa.jpg'),
                  )),
            )),
      ),
    );
  }

  watingview() {
    return Padding(
      padding: const EdgeInsets.only(top: 320),
      child: SpinKitThreeBounce(
        color: Colors.blueAccent[400],
        size: 25,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldkey,
        body: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ii == 3
                  ? profilepage()
                  : ii == 1
                      ? loginForm(context)
                      : ii == 2 ? signupForm(context) : watingview()
            ],
          ),
        ));
  }
}
