import 'dart:async';

import 'package:flutter/material.dart';

class PassPage extends StatelessWidget {
  const PassPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: PageState(),
    );
  }
}

class PageState extends StatefulWidget {
  @override
  PassState createState() => PassState();
}

class PassState extends State<PageState> {
  final GlobalKey<ScaffoldState> _curentstate = GlobalKey<ScaffoldState>();
  final passkey = GlobalKey<FormState>();
  final pass2key = GlobalKey<FormState>();
  final passvalue = TextEditingController();
  final pass2value = TextEditingController();

  pagepass() {
    return SingleChildScrollView(
      child: Container(
        child: Directionality(
          textDirection: TextDirection.rtl,
          child: Center(
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 35,
                ),
                Text(
                  'رمز عبور جدید خود را وارد کنید',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 15,
                ),
                Text(
                  "رمز عبور عبور خود را برای ورود سریع تر به خاطر بسپارید",
                  style: TextStyle(color: Colors.black26),
                ),
                SizedBox(
                  height: 45,
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      "رمز عبور",
                      style:
                          TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Container(
                  height: 60,
                  margin: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10),
                        bottomLeft: Radius.circular(10),
                        bottomRight: Radius.circular(10)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: TextFormField(
                      key: passkey,
                      controller: passvalue,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        hintText: 'رمز عبور',
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      "تکرار رمز عبور ",
                      style:
                          TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Container(
                  height: 60,
                  margin: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10),
                        bottomLeft: Radius.circular(10),
                        bottomRight: Radius.circular(10)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: TextFormField(
                      key: pass2key,
                      controller: pass2value,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        hintText: 'تکرار رمز عبور',
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 100,
                ),
                ClipRRect(
                  borderRadius: BorderRadius.circular(30),
                  child: Container(
                      width: 170,
                      height: 40,
                      color: Colors.blueAccent[700],
                      child: FlatButton(
                        splashColor: Colors.blueAccent[400].withOpacity(0.7),
                        child: Text(
                          'ثبت رمز عبور',
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                        onPressed: () {
                          setState(() {
                            passvalue.text == pass2value.text
                                ? sendpasslogin(passvalue.text)
                                : showMessage(
                                    "رمز عبور شما با تکرار ان تطابق ندارد");
                          });
                        },
                      )),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
  }

  sendpasslogin(String pass) {}

  showMessage(String value) {
    _curentstate.currentState.showSnackBar(SnackBar(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      content: Text(
        value,
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 18, color: Colors.white),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(key: _curentstate, body: pagepass());
  }
}
