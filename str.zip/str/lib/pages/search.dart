import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ToolbarSearch extends StatefulWidget {
  static const routeName = '/ToolbarSearch';
  @override
  _ToolbarSearchState createState() => _ToolbarSearchState();
}

class _ToolbarSearchState extends State<ToolbarSearch> {
  TextEditingController controller = new TextEditingController();

  // Get json result and convert it to model. Then add
  Future<Null> getUserDetails() async {
    final response = await http.get(url);
    final responseJson = json.decode(response.body);

    setState(() {
      for (var user in responseJson) {
        UserDetails userDetails =
            UserDetails(user["id"], user["namee"], user["desp"], user["price"]);

        _userDetails.add(userDetails);
      }
    });
  }

  contain(ty, tr, colorty, colortr, sizefont) {
    return Padding(
      padding: const EdgeInsets.only(top: 15, bottom: 15, left: 8, right: 8),
      child: RichText(
          text: TextSpan(
        children: <TextSpan>[
          TextSpan(
              text: ty,
              style: TextStyle(
                fontFamily: 'Vazir',
                fontSize: 15,
                color: colorty == "" ? Colors.black38 : colorty,
              )),
          TextSpan(
              text: tr,
              style: TextStyle(
                fontFamily: 'Vazir',
                fontSize: sizefont == "" ? 15 : sizefont,
                color: colortr == "" ? Colors.black87 : colortr,
              ))
        ],
      )),
    );
  }

  @override
  void initState() {
    super.initState();

    getUserDetails();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: new AppBar(
        backgroundColor: Colors.grey[300],
        centerTitle: true,
        title: Text(
          "جستجو در فروشگاه",
          style: TextStyle(
              color: Colors.black45,
              fontWeight: FontWeight.bold,
              fontFamily: 'Vazir',
              fontSize: 19),
        ),
        elevation: 5,
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: new Column(
          children: <Widget>[
            new Container(
              color: Colors.grey[300],
              child: new Padding(
                padding: const EdgeInsets.all(8.0),
                child: new Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30)),
                  child: new ListTile(
                    leading: new Icon(Icons.search),
                    title: new TextField(
                      controller: controller,
                      style: TextStyle(
                          color: Colors.grey[700],
                          fontFamily: 'Vazir',
                          fontSize: 17),
                      decoration: new InputDecoration(
                          focusColor: Colors.greenAccent[700],
                          hintText: 'Search',
                          border: InputBorder.none),
                      onChanged: onSearchTextChanged,
                    ),
                    trailing: new IconButton(
                      icon: new Icon(Icons.cancel),
                      onPressed: () {
                        controller.clear();
                        onSearchTextChanged('');
                      },
                    ),
                  ),
                ),
              ),
            ),
            new Expanded(
                child: ListView.builder(
              itemCount: _searchResult.length,
              itemBuilder: (context, i) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Card(
                    elevation: 8.0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: new Container(
                        width: MediaQuery.of(context).size.width,
                        height: 180,
                        color: Colors.white,
                        child: Row(
                          children: <Widget>[
                            Align(
                              alignment: Alignment.centerRight,
                              child: Container(
                                width: 150,
                                height: MediaQuery.of(context).size.height,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(15),
                                        bottomLeft: Radius.circular(15)),
                                    image: DecorationImage(
                                        fit: BoxFit.cover,
                                        image: NetworkImage(
                                            'http://192.168.198.1/img/aa.jpg'))),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(right: 20),
                              child: Align(
                                alignment: Alignment.center,
                                child: Container(
                                  height: MediaQuery.of(context).size.height,
                                  child: Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      contain(
                                          "دسته بندی : ",
                                          _searchResult[i].getDesp(),
                                          Colors.grey[700],
                                          Colors.grey[900],
                                          16.0),
                                      contain(
                                          " نام : ",
                                          _searchResult[i].getNamee(),
                                          Colors.grey[700],
                                          Colors.grey[900],
                                          16.0),
                                      contain(
                                          "قیمت : ",
                                          _searchResult[i].getPrice(),
                                          Colors.grey[700],
                                          Colors.grey[900],
                                          16.0)
                                    ],
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    margin: const EdgeInsets.all(0.0),
                  ),
                );
              },
            )),
          ],
        ),
      ),
    );
  }

  onSearchTextChanged(String text) async {
    _searchResult.clear();
    if (text.isEmpty) {
      setState(() {});
      return;
    }

    _userDetails.forEach((userDetail) {
      if (userDetail.getNamee().contains(text) ||
          userDetail.getNamee().contains(text)) _searchResult.add(userDetail);
    });

    setState(() {});
  }
}

List<UserDetails> _searchResult = [];

List<UserDetails> _userDetails = [];

final String url = 'http://192.168.198.1/select.php';

class UserDetails {
  final String id;
  final String namee, desp, price;

  UserDetails(this.id, this.namee, this.desp, this.price);

  getid() {
    return id;
  }

  getNamee() {
    return namee;
  }

  getDesp() {
    return desp;
  }

  getPrice() {
    return price;
  }

  /*factory UserDetails.fromJson(Map<String, dynamic> json) {
    return new UserDetails(
    ///  id: json['id'],
     // firstName: json['name'],
    /// lastName: json['username'],
    /// 
    getName(){
      return
    }


    );
  }*/
}
