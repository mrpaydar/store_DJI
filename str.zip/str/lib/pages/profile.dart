import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';

class Profile extends StatelessWidget {
  const Profile({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Prof(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class Prof extends StatefulWidget {
  Prof({Key key}) : super(key: key);

  @override
  _ProfState createState() => _ProfState();
}

class mycliper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();

    path.moveTo(0, 0);
    path.lineTo(0, size.height - 55);
    path.lineTo(size.width - 130, size.height);
    path.lineTo(size.width, size.height);
    path.lineTo(size.width, 0);
    path.close();

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}

class _ProfState extends State<Prof> {
  List<String> names = [
    "سفارشات",
    "لیست مورد علاقه",
    "ادرس",
    "اطلاعات حساب کاربری",
    "ارتباط با ما"
  ];

  Icon ic1 = Icon(Icons.format_list_numbered_rtl);
  Icon ic2 = Icon(Icons.favorite);
  Icon ic3 = Icon(Icons.device_hub);
  Icon ic4 = Icon(Icons.person_outline);
  Icon ic5 = Icon(Icons.transfer_within_a_station);

  profilepage() {
    return SingleChildScrollView(
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Column(
          children: <Widget>[
            ClipPath(
              clipper: mycliper(),
              child: ClipRRect(
                borderRadius:
                    BorderRadius.only(bottomRight: Radius.elliptical(115, 115)),
                child: Container(
                  height: 260,
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: const FractionalOffset(0.0, 0.0),
                          end: const FractionalOffset(0.0, 1.3),
                          stops: [0.0, 1.0],
                          tileMode: TileMode.mirror,
                          colors: [
                            const Color(0xFF00CCFF),
                            const Color(0xFF3366FF),
                          ])),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      SizedBox(
                        height: 60,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: <Widget>[
                          Row(
                            children: <Widget>[],
                          ),
                          Row(
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.only(left: 38),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Text(
                                      "نام ونام خانوادگی",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 19,
                                          fontFamily: 'Vazir'),
                                    ),
                                    Text(
                                      " شماره",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontFamily: 'Vazir',
                                          fontSize: 17,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ],
                                ),
                              ),
                              GestureDetector(
                                onTap: () {},
                                child: Container(
                                  width: 100,
                                  height: 100,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      shape: BoxShape.circle,
                                      image: DecorationImage(
                                          fit: BoxFit.cover,
                                          image: NetworkImage(
                                              "http://192.168.198.1/img/bb.jpg"))),
                                ),
                              ),
                            ],
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  mylistview() {
    return SingleChildScrollView(
      child: SizedBox(
        height: 400,
        child: ListView.separated(
          shrinkWrap: true,
          itemCount: names.length,
          itemBuilder: ((context, index) {
            return ListTile(
              trailing: Icon(Icons.navigate_next),
              title: Text(
                names[index],
                style: TextStyle(fontFamily: 'Vazir', fontSize: 18),
              ),
              leading: names[index] == "سفارشات"
                  ? ic1
                  : names[index] == "ادرس"
                      ? ic3
                      : names[index] == "اطلاعات حساب کاربری"
                          ? ic4
                          : names[index] == "ارتباط با ما" ? ic5 : ic2,
            );
          }),
          separatorBuilder: (BuildContext context, int index) {
            return Padding(
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Divider(
                color: Colors.black54,
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      physics: ScrollPhysics(),
      child: Directionality(
          textDirection: TextDirection.rtl,
          child: Column(
            children: <Widget>[profilepage(), mylistview()],
          )),
    ));
  }
}
